package servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.*;
import java.sql.*;
import java.util.*;

import db.DBConnection;

@WebServlet("/orderHistory")
public class OrderHistoryServlet extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {

		HttpSession session = req.getSession();
		Integer userId = (Integer) session.getAttribute("userId");

		if (userId == null) {
			res.sendRedirect("login.jsp");
			return;
		}

		List<Map<String, String>> orderList = new ArrayList<>();
		try {
			Connection con = DBConnection.getConnection();

			String sql = "SELECT o.id AS order_id, o.order_date, o.total_amount, " +
					"m.name AS menu_name, m.price, oi.quantity, r.name AS restaurant_name " +
					"FROM `order` o " +  														// ✅ use backticks for reserved keyword
					"JOIN order_item oi ON o.id = oi.order_id " +
					"JOIN menu m ON oi.menu_id = m.id " +
					"JOIN restaurant r ON m.restaurant_id = r.restaurantId " +
					"WHERE o.user_id = ? " +
					"ORDER BY o.order_date DESC";

			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, userId);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				Map<String, String> order = new HashMap<>();
				order.put("orderId", String.valueOf(rs.getInt("order_id")));
				order.put("order_date", rs.getString("order_date"));
				order.put("menuName", rs.getString("menu_name"));
				order.put("price", rs.getString("price"));
				order.put("quantity", rs.getString("quantity"));
				order.put("restaurantName", rs.getString("restaurant_name"));
				orderList.add(order);
			}

			req.setAttribute("orders", orderList);
			RequestDispatcher dispatcher = req.getRequestDispatcher("orderHistory.jsp");
			dispatcher.forward(req, res);

		} catch (Exception e) {
			e.printStackTrace();
			res.getWriter().println("Failed to load order history.");
		}
	}
	
	
	 // DELETE ORDER
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        HttpSession session = req.getSession();
        Integer userId = (Integer) session.getAttribute("userId");

        if (userId == null) {
            res.sendRedirect("login.jsp");
            return;
        }

        String orderIdStr = req.getParameter("orderId");
        if (orderIdStr == null || orderIdStr.trim().isEmpty()) {
            res.sendRedirect("orderHistory");
            return;
        }

        try {
            int orderId = Integer.parseInt(orderIdStr);
            Connection con = DBConnection.getConnection();

            // Delete from order_item first (due to FK constraint)
            PreparedStatement psDeleteItems = con.prepareStatement("DELETE FROM order_item WHERE order_id = ?");
            psDeleteItems.setInt(1, orderId);
            psDeleteItems.executeUpdate();

            // Then delete from order table
            PreparedStatement psDeleteOrder = con.prepareStatement("DELETE FROM `order` WHERE id = ? AND user_id = ?");
            psDeleteOrder.setInt(1, orderId);
            psDeleteOrder.setInt(2, userId);
            psDeleteOrder.executeUpdate();

            res.sendRedirect("orderHistory");

        } catch (Exception e) {
            e.printStackTrace();
            res.getWriter().println("Error deleting order.");
        }
    }
}
