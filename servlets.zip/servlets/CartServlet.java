package servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.*;

import db.DBConnection;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false); //Checks if a user is logged in If not redirects the user to login.jsp
        Integer userId = (session != null) ? (Integer) session.getAttribute("userId") : null;
        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        String action = request.getParameter("action");
        
     // ✅ 1. Handle Remove Item First
        if ("remove".equals(action)) {
            String cartItemIdStr = request.getParameter("cartItemId");//Reads the cart item ID from the request
            
            if (cartItemIdStr != null && !cartItemIdStr.isEmpty()) { //Checks if the ID is not null and not empty to avoid errors.
                int cartItemId = Integer.parseInt(cartItemIdStr);	//Converts the string to an integer 
                
                try (Connection con = DBConnection.getConnection()) {
                    PreparedStatement deleteStmt = con.prepareStatement("DELETE FROM cart_item WHERE id = ?"); //remove the row from cart_item 
                    deleteStmt.setInt(1, cartItemId);
                    deleteStmt.executeUpdate();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            response.sendRedirect("cart.jsp"); //After deleting user is redirected back to the cart page
            return;
        }
        
        String menuIdStr = request.getParameter("menuId");//If menuId is present in the request, it means the user clicked “Add to Cart”.
        String amountStr = request.getParameter("amount");
        String restaurantId = request.getParameter("restaurantId");

        try (Connection con = DBConnection.getConnection()) {
            if (menuIdStr != null) {
                int menuId = Integer.parseInt(menuIdStr);

                PreparedStatement checkCartStmt = con.prepareStatement("SELECT id FROM cart WHERE user_id = ?");//Checks if the user has an active cart.
                checkCartStmt.setInt(1, userId);
                ResultSet cartRs = checkCartStmt.executeQuery();
                int cartId;
                
                if (cartRs.next()) {
                    cartId = cartRs.getInt("id");
                } else {
                	//insert a new row into the cart table and allows you to retrieve the auto-generated primary key (cart ID) immediately after the insert.
                    PreparedStatement insertCartStmt = con.prepareStatement("INSERT INTO cart(user_id) VALUES (?)", Statement.RETURN_GENERATED_KEYS);
                    insertCartStmt.setInt(1, userId);
                    insertCartStmt.executeUpdate();
                    ResultSet generatedKeys = insertCartStmt.getGeneratedKeys();//gives the auto generated primary key
                    generatedKeys.next();
                    cartId = generatedKeys.getInt(1);
                }
                
                //check if a particular menu item already exists in the user’s cart
                PreparedStatement checkItem = con.prepareStatement("SELECT id, quantity FROM cart_item WHERE cart_id = ? AND menu_id = ?");
                checkItem.setInt(1, cartId);
                checkItem.setInt(2, menuId);
                ResultSet itemRs = checkItem.executeQuery();

                if (itemRs.next()) {
                    int existingQty = itemRs.getInt("quantity");
                    PreparedStatement updateQty = con.prepareStatement("UPDATE cart_item SET quantity = ? WHERE id = ?");// update the quantity 
                    updateQty.setInt(1, existingQty + 1);
                    updateQty.setInt(2, itemRs.getInt("id"));
                    updateQty.executeUpdate();
                } 
                else {
                	// add a new item into the cart.
                    PreparedStatement insertItem = con.prepareStatement("INSERT INTO cart_item(cart_id, menu_id, quantity) VALUES (?, ?, ?)");
                    insertItem.setInt(1, cartId);
                    insertItem.setInt(2, menuId);
                    insertItem.setInt(3, 1);
                    insertItem.executeUpdate();
                }

                // ✅ Redirect back to menu with restaurantId
                if (restaurantId != null && !restaurantId.isEmpty()) {
                    response.sendRedirect("menu?restaurantId=" + restaurantId);
                } else {
                    response.sendRedirect("menu");
                }

            } else if (amountStr != null) {
                double totalAmount = Double.parseDouble(amountStr);

                PreparedStatement getCartId = con.prepareStatement("SELECT id FROM cart WHERE user_id = ?");
                getCartId.setInt(1, userId);
                ResultSet cartRs = getCartId.executeQuery();

                if (cartRs.next()) {
                    int cartId = cartRs.getInt("id");

                    PreparedStatement insertOrder = con.prepareStatement("INSERT INTO `order`(user_id, total_amount) VALUES (?, ?)", Statement.RETURN_GENERATED_KEYS);
                    insertOrder.setInt(1, userId);
                    insertOrder.setDouble(2, totalAmount);
                    insertOrder.executeUpdate();

                    ResultSet generatedKeys = insertOrder.getGeneratedKeys();
                    generatedKeys.next();
                    int orderId = generatedKeys.getInt(1);

                    PreparedStatement fetchCartItems = con.prepareStatement("SELECT menu_id, quantity FROM cart_item WHERE cart_id = ?");
                    fetchCartItems.setInt(1, cartId);
                    ResultSet itemRs = fetchCartItems.executeQuery();

                    while (itemRs.next()) {
                        int menuId = itemRs.getInt("menu_id");
                        int quantity = itemRs.getInt("quantity");

                        PreparedStatement insertOrderItem = con.prepareStatement("INSERT INTO order_item(order_id, menu_id, quantity) VALUES (?, ?, ?)");
                        insertOrderItem.setInt(1, orderId);
                        insertOrderItem.setInt(2, menuId);
                        insertOrderItem.setInt(3, quantity);
                        insertOrderItem.executeUpdate();
                    }

                    PreparedStatement clearCart = con.prepareStatement("DELETE FROM cart_item WHERE cart_id = ?");
                    clearCart.setInt(1, cartId);
                    clearCart.executeUpdate();
                }

                response.sendRedirect("order.jsp");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
