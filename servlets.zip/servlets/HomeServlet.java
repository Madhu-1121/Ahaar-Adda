package servlets;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import db.DBConnection;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        List<Map<String, String>> restaurants = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM restaurant");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, String> rest = new HashMap<>();
                rest.put("id", String.valueOf(rs.getInt("restaurantId")));
                rest.put("name", rs.getString("name"));
                rest.put("address", rs.getString("address"));
                rest.put("phoneNumber", rs.getString("phoneNumber"));
                rest.put("imageUrl", rs.getString("imageUrl"));
                rest.put("rating", rs.getString("rating")); // Added rating
                restaurants.add(rest);
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        req.setAttribute("restaurants", restaurants);
        RequestDispatcher rd = req.getRequestDispatcher("home.jsp");
        rd.forward(req, res);
    }
}
