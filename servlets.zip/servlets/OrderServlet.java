package servlets;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.sql.*;
import db.DBConnection;

public class OrderServlet extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Integer userId = (Integer) session.getAttribute("userId");  // fixed here

        if (userId == null) {
            res.sendRedirect("login.jsp");  // fixed path
            return;
        }

        try {
            Connection con = DBConnection.getConnection();

            // 1. Get cart ID
            PreparedStatement psCartId = con.prepareStatement("SELECT id FROM cart WHERE user_id = ?");
            psCartId.setInt(1, userId);
            ResultSet rsCartId = psCartId.executeQuery();

            int cartId = -1;
            if (rsCartId.next()) {
                cartId = rsCartId.getInt("id");
            }

            if (cartId == -1) {
                res.getWriter().println("No cart found for user.");
                return;
            }

            // 2. Create order
            PreparedStatement psOrder = con.prepareStatement(
                "INSERT INTO orders(user_id, created_at) VALUES(?, NOW())", Statement.RETURN_GENERATED_KEYS);
            psOrder.setInt(1, userId);
            psOrder.executeUpdate();

            ResultSet rsOrder = psOrder.getGeneratedKeys();
            int orderId = 0;
            if (rsOrder.next()) {
                orderId = rsOrder.getInt(1);
            }

            // 3. Copy cart items to order_item
            PreparedStatement psCartItems = con.prepareStatement(
                "SELECT menu_id, quantity FROM cart_item WHERE cart_id = ?");
            psCartItems.setInt(1, cartId);
            ResultSet rsItems = psCartItems.executeQuery();

            while (rsItems.next()) {
                int menuId = rsItems.getInt("menu_id");
                int qty = rsItems.getInt("quantity");

                PreparedStatement psInsertOrderItem = con.prepareStatement(
                    "INSERT INTO order_item(order_id, menu_id, quantity) VALUES (?, ?, ?)");
                psInsertOrderItem.setInt(1, orderId);
                psInsertOrderItem.setInt(2, menuId);
                psInsertOrderItem.setInt(3, qty);
                psInsertOrderItem.executeUpdate();
            }

            // 4. Clear cart items
            PreparedStatement psClearCart = con.prepareStatement("DELETE FROM cart_item WHERE cart_id = ?");
            psClearCart.setInt(1, cartId);
            psClearCart.executeUpdate();

            res.sendRedirect("orderHistory"); // redirect to history page

        } catch (Exception e) {
            e.printStackTrace();
            res.getWriter().println("Error placing order.");
        }
    }
}
