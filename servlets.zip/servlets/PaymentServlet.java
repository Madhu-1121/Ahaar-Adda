package servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;
import java.sql.*;
import db.DBConnection;

@WebServlet("/PaymentServlet")
public class PaymentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession(false);
        Integer userId = (session != null) ? (Integer) session.getAttribute("userId") : null;
        String paymentMethod = request.getParameter("paymentMethod");

        if (userId == null || paymentMethod == null || paymentMethod.isEmpty()) {
            response.getWriter().println("Error placing order.");
            return;
        }

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            con = DBConnection.getConnection();

            // Get cart ID
            ps = con.prepareStatement("SELECT id FROM cart WHERE user_id = ?");
            ps.setInt(1, userId);
            rs = ps.executeQuery();
            int cartId = -1;
            if (rs.next()) {
                cartId = rs.getInt("id");
            } else {
                response.getWriter().println("Cart not found.");
                return;
            }
            rs.close();
            ps.close();

            // Create new order
            ps = con.prepareStatement("INSERT INTO `order` (user_id, order_date, payment_method) VALUES (?, NOW(), ?)", Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, userId);
            ps.setString(2, paymentMethod);
            ps.executeUpdate();
            rs = ps.getGeneratedKeys();
            int orderId = -1;
            if (rs.next()) {
                orderId = rs.getInt(1);
            } else {
                response.getWriter().println("Failed to create order.");
                return;
            }
            rs.close();
            ps.close();

            // Copy items from cart_item to order_item
            ps = con.prepareStatement("SELECT menu_id, quantity FROM cart_item WHERE cart_id = ?");
            ps.setInt(1, cartId);
            rs = ps.executeQuery();
            PreparedStatement orderItemInsert = con.prepareStatement("INSERT INTO order_item (order_id, menu_id, quantity) VALUES (?, ?, ?)");
            while (rs.next()) {
                orderItemInsert.setInt(1, orderId);
                orderItemInsert.setInt(2, rs.getInt("menu_id"));
                orderItemInsert.setInt(3, rs.getInt("quantity"));
                orderItemInsert.executeUpdate();
            }
            rs.close();
            ps.close();
            orderItemInsert.close();

            // Clear cart items
            ps = con.prepareStatement("DELETE FROM cart_item WHERE cart_id = ?");
            ps.setInt(1, cartId);
            ps.executeUpdate();
            ps.close();

            // Redirect to confirmation page
            response.sendRedirect("order.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error placing order.");
        } finally {
            try { if (rs != null) rs.close(); } catch (Exception ignored) {}
            try { if (ps != null) ps.close(); } catch (Exception ignored) {}
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }
    }
}
