package servlets;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.*;
import java.util.*;

import db.DBConnection;

@WebServlet("/menu")
public class MenuServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String restaurantIdStr = request.getParameter("restaurantId");
        List<Map<String, String>> menuItems = new ArrayList<>();
        Connection con = null;

        try {
            con = DBConnection.getConnection();
            PreparedStatement ps;

            if (restaurantIdStr != null && !restaurantIdStr.trim().isEmpty()) {
                // Filter by restaurantId
                int restaurantId = Integer.parseInt(restaurantIdStr);
                ps = con.prepareStatement("SELECT id, name, description, price, imageUrl FROM menu WHERE restaurant_id = ?");
                ps.setInt(1, restaurantId);
                request.setAttribute("restaurantId", restaurantId);
            } else {
                // No restaurantId provided → Show all menu items
                ps = con.prepareStatement("SELECT id, name, description, price, imageUrl FROM menu");
            }

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Map<String, String> item = new HashMap<>();
                item.put("id", String.valueOf(rs.getInt("id")));
                item.put("name", rs.getString("name"));
                item.put("description", rs.getString("description"));
                item.put("price", rs.getString("price"));
                item.put("imageUrl", rs.getString("imageUrl"));
                menuItems.add(item);
            }

            rs.close();
            ps.close();

            request.setAttribute("menuItems", menuItems);
            RequestDispatcher dispatcher = request.getRequestDispatcher("menu.jsp");
            dispatcher.forward(request, response);

        } catch (NumberFormatException e) {
            response.getWriter().println("Invalid restaurant ID.");
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error loading menu.");
        } finally {
            try { if (con != null) con.close(); } catch (Exception ignored) {}
        }
    }
}
